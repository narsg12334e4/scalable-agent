"""
Scalable Agentic System - Reference Implementation
Demonstrating:
1. Massive Tool Catalog (50+ APIs categorized)
2. Semantic Tool Retrieval (JIT Dynamic Tool Scoping)
3. Hierarchical Routing (Manager -> Specialist Agent)
4. Dedicated RAG Pipeline Tool (Doc search)
5. Dedicated System Search Tool (Metacognition / capability search & state inspect)
6. Error Handling & Parameter Self-Correction
"""

import math
import re
import json
import datetime
from typing import Dict, List, Any, Optional

# =====================================================================
# 1. TOOL REGISTRY (Simulating 50+ PayPal & Enterprise APIs)
# =====================================================================

TOOL_CATALOG = [
    # Invoicing Domain
    {
        "id": "paypal_invoices_create_draft",
        "domain": "invoicing",
        "name": "Create Draft Invoice",
        "description": "Create a new draft invoice with recipient email, line items, and amount.",
        "parameters": {"recipient_email": "string", "amount": "float", "currency": "string"},
        "required": ["recipient_email", "amount"]
    },
    {
        "id": "paypal_invoices_send",
        "domain": "invoicing",
        "name": "Send Invoice",
        "description": "Send an existing draft invoice to the recipient via email and activate payment link.",
        "parameters": {"invoice_id": "string"},
        "required": ["invoice_id"]
    },
    {
        "id": "paypal_invoices_cancel",
        "domain": "invoicing",
        "name": "Cancel Invoice",
        "description": "Cancel an unpaid sent invoice and notify the recipient.",
        "parameters": {"invoice_id": "string", "reason": "string"},
        "required": ["invoice_id"]
    },
    {
        "id": "paypal_invoices_get",
        "domain": "invoicing",
        "name": "Get Invoice Details",
        "description": "Retrieve full details and payment status of an invoice by ID.",
        "parameters": {"invoice_id": "string"},
        "required": ["invoice_id"]
    },
    {
        "id": "paypal_invoices_list",
        "domain": "invoicing",
        "name": "List Invoices",
        "description": "List all invoices with optional status filter (DRAFT, SENT, PAID, CANCELLED).",
        "parameters": {"status": "string", "limit": "int"},
        "required": []
    },

    # Payments & Transactions Domain
    {
        "id": "paypal_payments_capture",
        "domain": "payments",
        "name": "Capture Payment",
        "description": "Capture an authorized payment order to settle funds into merchant account.",
        "parameters": {"authorization_id": "string", "amount": "float"},
        "required": ["authorization_id"]
    },
    {
        "id": "paypal_payments_refund",
        "domain": "payments",
        "name": "Refund Payment",
        "description": "Refund a captured transaction partially or in full back to buyer.",
        "parameters": {"capture_id": "string", "amount": "float", "note": "string"},
        "required": ["capture_id"]
    },
    {
        "id": "paypal_payments_create_order",
        "domain": "payments",
        "name": "Create Payment Order",
        "description": "Create an order intent for checkout payment flow.",
        "parameters": {"amount": "float", "currency": "string"},
        "required": ["amount", "currency"]
    },

    # Disputes & Risk Domain
    {
        "id": "paypal_disputes_list",
        "domain": "disputes",
        "name": "List Disputes",
        "description": "Search and list open customer disputes, claims, chargebacks, and inquiry statuses.",
        "parameters": {"customer_id": "string", "status": "string"},
        "required": []
    },
    {
        "id": "paypal_disputes_provide_evidence",
        "domain": "disputes",
        "name": "Provide Dispute Evidence",
        "description": "Submit tracking numbers or documentation proof for an active dispute.",
        "parameters": {"dispute_id": "string", "tracking_number": "string", "carrier": "string"},
        "required": ["dispute_id", "tracking_number"]
    },
    {
        "id": "paypal_disputes_accept_claim",
        "domain": "disputes",
        "name": "Accept Dispute Claim",
        "description": "Accept customer dispute claim and authorize full refund to resolve issue.",
        "parameters": {"dispute_id": "string"},
        "required": ["dispute_id"]
    },

    # Reporting & Analytics Domain
    {
        "id": "paypal_reports_sales_volume",
        "domain": "reporting",
        "name": "Get Sales Volume Summary",
        "description": "Pull total sales volume, transaction counts, and gross revenue over date range.",
        "parameters": {"start_date": "string", "end_date": "string"},
        "required": ["start_date", "end_date"]
    },
    {
        "id": "paypal_reports_account_balances",
        "domain": "reporting",
        "name": "Get Account Balances",
        "description": "Retrieve current primary and secondary currency balances held in merchant account.",
        "parameters": {"currency": "string"},
        "required": []
    },

    # Built-in Core Feature 1: RAG Pipeline Tool
    {
        "id": "rag_knowledge_search",
        "domain": "knowledge",
        "name": "Query Knowledge Base",
        "description": "Query product guides, fee schedules, dispute policies, and API documentation.",
        "parameters": {"query": "string"},
        "required": ["query"]
    },

    # Built-in Core Feature 2: System Search Tool
    {
        "id": "system_search",
        "domain": "system",
        "name": "System Metacognitive Search",
        "description": "Search available system tools, capabilities, request status, and execution logs.",
        "parameters": {"query_type": "string", "query": "string"},
        "required": ["query_type", "query"]
    }
]

# Adding 40 dummy enterprise APIs to reach 50+ total tools
for i in range(1, 41):
    domain = ["invoicing", "payments", "disputes", "reporting", "webhooks", "subscriptions"][i % 6]
    TOOL_CATALOG.append({
        "id": f"enterprise_api_{domain}_{i}",
        "domain": domain,
        "name": f"Enterprise {domain.capitalize()} Operation {i}",
        "description": f"Extended utility endpoint {i} for managing enterprise {domain} lifecycle actions.",
        "parameters": {"entity_id": "string", "options": "dict"},
        "required": ["entity_id"]
    })

# Total tools is now > 50
print(f"[System Init] Total tools indexed in Tool Catalog: {len(TOOL_CATALOG)}")


# =====================================================================
# 2. SEMANTIC TOOL RETRIEVER (Dynamic Tool RAG)
# =====================================================================

class SimpleSemanticRetriever:
    """
    Lightweight embedding / BM25 simulator using token overlap and tf-idf cosine similarity.
    In production, this is backed by Qdrant, Milvus, or FAISS with bge-large/text-embedding-3.
    """
    def __init__(self, catalog: List[Dict[str, Any]]):
        self.catalog = catalog

    def _tokenize(self, text: str) -> List[str]:
        return re.findall(r'\w+', text.lower())

    def search(self, query: str, domain: Optional[str] = None, top_k: int = 3) -> List[Dict[str, Any]]:
        q_tokens = set(self._tokenize(query))
        scores = []
        for tool in self.catalog:
            # Domain filter boost
            domain_multiplier = 2.0 if (domain and tool["domain"] == domain) else 1.0
            
            tool_text = f"{tool['name']} {tool['description']} {tool['domain']} {' '.join(tool['parameters'].keys())}"
            t_tokens = self._tokenize(tool_text)
            
            if not t_tokens:
                continue
                
            overlap = len(q_tokens.intersection(t_tokens))
            score = (overlap / (math.sqrt(len(q_tokens)) * math.sqrt(len(t_tokens)) + 1e-5)) * domain_multiplier
            scores.append((score, tool))

        scores.sort(key=lambda x: x[0], reverse=True)
        return [tool for score, tool in scores[:top_k]]


# =====================================================================
# 3. MOCK EXECUTION ENVIRONMENT & KNOWLEDGE BASE
# =====================================================================

KNOWLEDGE_BASE = {
    "fees": "PayPal invoice processing fee is 2.99% + $0.49 per standard domestic transaction. International transactions have an additional 1.50% cross-border fee.",
    "disputes": "Chargeback dispute response window is 10 calendar days. Sellers must upload proof of delivery or tracking ID.",
    "invoicing": "Draft invoices can be edited at any time. Once sent, invoices cannot be modified, only cancelled or reminded."
}

EXECUTION_LOGS = [
    {"task_id": "task_1001", "action": "paypal_invoices_send", "status": "SUCCESS", "timestamp": "2026-09-19 10:15:00"},
    {"task_id": "task_1002", "action": "paypal_disputes_list", "status": "COMPLETED", "timestamp": "2026-09-19 11:30:00"}
]


def execute_tool_call(tool_id: str, args: Dict[str, Any]) -> Dict[str, Any]:
    """Simulates API execution with parameter validation."""
    tool = next((t for t in TOOL_CATALOG if t["id"] == tool_id), None)
    if not tool:
        return {"error": f"Tool '{tool_id}' does not exist"}

    # Validation: check required arguments
    for req in tool["required"]:
        if req not in args or args[req] is None or args[req] == "":
            return {"error": f"Validation Error: Missing required parameter '{req}' for tool '{tool_id}'"}

    # Concrete PayPal Logic Simulation
    if tool_id == "paypal_invoices_create_draft":
        return {
            "invoice_id": "INV2-9842-XKJ",
            "status": "DRAFT",
            "recipient": args.get("recipient_email"),
            "amount": args.get("amount"),
            "currency": args.get("currency", "USD"),
            "created_at": datetime.datetime.now().isoformat()
        }

    elif tool_id == "paypal_invoices_send":
        return {
            "invoice_id": args.get("invoice_id"),
            "status": "SENT",
            "payment_link": f"https://www.paypal.com/invoice/p/#{args.get('invoice_id')}",
            "message": "Invoice sent successfully via email."
        }

    elif tool_id == "paypal_reports_sales_volume":
        return {
            "start_date": args.get("start_date"),
            "end_date": args.get("end_date"),
            "total_sales_volume": 12850.50,
            "currency": "USD",
            "total_orders": 94,
            "net_revenue": 12467.20
        }

    elif tool_id == "paypal_disputes_list":
        cust = args.get("customer_id")
        if cust == "user_123":
            return {
                "disputes": [
                    {
                        "dispute_id": "DISP-88319",
                        "customer_id": "user_123",
                        "status": "UNDER_REVIEW",
                        "reason": "ITEM_NOT_RECEIVED",
                        "disputed_amount": 50.00,
                        "currency": "USD",
                        "response_deadline": "2026-09-25T23:59:59Z"
                    }
                ]
            }
        return {"disputes": [], "message": f"No open disputes found for {cust}."}

    # Core Feature 1: RAG Pipeline Tool
    elif tool_id == "rag_knowledge_search":
        q = args.get("query", "").lower()
        results = []
        for topic, text in KNOWLEDGE_BASE.items():
            if topic in q or any(word in text.lower() for word in q.split()):
                results.append(f"[{topic.upper()}] {text}")
        return {"knowledge_snippets": results or ["No direct matching documentation found."]}

    # Core Feature 2: System Search Tool
    elif tool_id == "system_search":
        q_type = args.get("query_type")
        q = args.get("query", "").lower()
        if q_type == "capabilities":
            # Search tool catalog
            matching = [t["id"] + ": " + t["description"] for t in TOOL_CATALOG if q in t["id"] or q in t["domain"] or q in t["name"].lower()]
            return {"matching_tools": matching[:5], "total_matches": len(matching)}
        elif q_type in ["request_status", "execution_logs"]:
            return {"logs": EXECUTION_LOGS}
        return {"status": "Unknown query_type. Use 'capabilities' or 'request_status'."}

    return {"status": "SUCCESS", "result": f"Executed {tool_id} successfully."}


# =====================================================================
# 4. HIERARCHICAL ORCHESTRATOR & AGENT PIPELINE
# =====================================================================

class ScalableAgentSystem:
    def __init__(self):
        self.retriever = SimpleSemanticRetriever(TOOL_CATALOG)

    def route_domain(self, query: str) -> str:
        """Step 1: Lightweight Intent Classifier (Global Router)"""
        q = query.lower()
        if any(w in q for w in ["what tools", "status of", "system", "logs", "capabilities"]):
            return "system"
        if any(w in q for w in ["fee", "policy", "guide", "documentation", "how does"]):
            return "knowledge"
        if any(w in q for w in ["invoice", "bill", "billing"]):
            return "invoicing"
        if any(w in q for w in ["sales", "volume", "report", "revenue", "balances"]):
            return "reporting"
        if any(w in q for w in ["dispute", "claim", "chargeback"]):
            return "disputes"
        if any(w in q for w in ["pay", "refund", "capture", "order"]):
            return "payments"
        return "general"

    def process_query(self, user_query: str) -> str:
        print(f"\n==================================================================")
        print(f"USER QUERY: \"{user_query}\"")
        print(f"==================================================================")

        # 1. Route Intent
        domain = self.route_domain(user_query)
        print(f"[Tier 1 Router] Detected Domain: '{domain.upper()}'")

        # 2. Dynamic Tool Retrieval (Tool RAG)
        scoped_tools = self.retriever.search(query=user_query, domain=domain, top_k=3)
        print(f"[Tool RAG] Dynamically scoped {len(scoped_tools)} relevant tools out of {len(TOOL_CATALOG)}:")
        for t in scoped_tools:
            print(f"   -> [{t['id']}] {t['name']}")

        # 3. Agent Execution Simulation based on Scoped Tools
        # Let's handle our concrete scenarios
        q = user_query.lower()

        if "send an invoice for $50" in q:
            # Need draft + send
            print("\n[Domain Agent: Invoicing] Planning 2-step execution...")
            print("Step 1: Call 'paypal_invoices_create_draft'")
            res1 = execute_tool_call("paypal_invoices_create_draft", {"recipient_email": "client@example.com", "amount": 50.0})
            print(f"   Response: {res1}")

            print("Step 2: Call 'paypal_invoices_send' using generated invoice_id")
            res2 = execute_tool_call("paypal_invoices_send", {"invoice_id": res1["invoice_id"]})
            print(f"   Response: {res2}")
            return f"Invoice {res1['invoice_id']} for $50.00 USD has been successfully created and sent to client@example.com."

        elif "sales volume" in q:
            print("\n[Domain Agent: Reporting] Calling 'paypal_reports_sales_volume'...")
            res = execute_tool_call("paypal_reports_sales_volume", {"start_date": "2026-08-01", "end_date": "2026-08-31"})
            print(f"   Response: {res}")
            return f"Your total sales volume for last month was ${res['total_sales_volume']:,.2f} USD across {res['total_orders']} orders."

        elif "dispute open from user_123" in q:
            print("\n[Domain Agent: Disputes] Calling 'paypal_disputes_list' with customer_id=user_123...")
            res = execute_tool_call("paypal_disputes_list", {"customer_id": "user_123"})
            print(f"   Response: {res}")
            d = res["disputes"][0]
            return f"Yes, there is an open dispute ({d['dispute_id']}) for user_123 in status '{d['status']}'. Disputed amount: ${d['disputed_amount']:.2f} (Reason: {d['reason']}). Response deadline: {d['response_deadline']}."

        elif "what tools are available for managing invoices" in q:
            print("\n[System Search Tool] Inspecting capability manifest...")
            res = execute_tool_call("system_search", {"query_type": "capabilities", "query": "invoice"})
            print(f"   Response: {res}")
            return f"Available Invoicing Tools:\n" + "\n".join([f"- {t}" for t in res["matching_tools"]])

        elif "what are the fees" in q:
            print("\n[RAG Pipeline Tool] Querying knowledge base...")
            res = execute_tool_call("rag_knowledge_search", {"query": "fees"})
            print(f"   Response: {res}")
            return f"Knowledge Base Result:\n{res['knowledge_snippets'][0]}"

        elif "trigger error test" in q:
            print("\n[Error Handling & Reflection Test] Calling tool with missing required param...")
            res = execute_tool_call("paypal_invoices_create_draft", {"amount": 50.0}) # missing recipient_email
            print(f"   Initial Call Failure: {res}")
            print("   -> Self-Correction Loop Triggered: Agent inspects error and supplies default/re-prompted recipient...")
            corrected_res = execute_tool_call("paypal_invoices_create_draft", {"recipient_email": "fallback@example.com", "amount": 50.0})
            print(f"   Corrected Call Response: {corrected_res}")
            return f"Successfully recovered from schema error! Created invoice {corrected_res['invoice_id']}."

        # Dynamic fallback execution based on scoped tools
        if scoped_tools:
            primary_tool = scoped_tools[0]
            print(f"\n[Domain Agent: {domain.upper()}] Selected primary retrieved tool: '{primary_tool['id']}'")
            return f"I routed your query to the '{domain.upper()}' domain and scoped '{primary_tool['name']}' ({primary_tool['id']}) out of {len(TOOL_CATALOG)} tools. Action ready to execute with parameters: {list(primary_tool['parameters'].keys())}."

        return "Query processed successfully."


# =====================================================================
# 5. DEMO & INTERACTIVE EXECUTION
# =====================================================================

if __name__ == "__main__":
    import sys
    system = ScalableAgentSystem()

    if "--interactive" in sys.argv or "-i" in sys.argv:
        print("\n" + "=" * 62)
        print("   SCALABLE AGENTIC SYSTEM - INTERACTIVE CHAT MODE")
        print("   Type your natural language request below.")
        print("   Examples:")
        print("    * 'Send an invoice for $50 to client@example.com'")
        print("    * 'What was my total sales volume last month?'")
        print("    * 'Is there a dispute open from user_123?'")
        print("    * 'What tools are available for managing invoices?'")
        print("    * 'What are the fees for transactions?'")
        print("   Type 'exit' or 'quit' to exit.")
        print("=" * 62 + "\n")

        while True:
            try:
                user_input = input("You: ").strip()
                if not user_input:
                    continue
                if user_input.lower() in ["exit", "quit", "q"]:
                    print("\nExiting interactive mode. Goodbye!")
                    break
                answer = system.process_query(user_input)
                print(f"\nFINAL AGENT ANSWER:\n{answer}\n")
            except (KeyboardInterrupt, EOFError):
                print("\nExiting. Goodbye!")
                break
    else:
        queries = [
            "Send an invoice for $50 to client@example.com",
            "What was my total sales volume last month?",
            "Is there a dispute open from user_123?",
            "What tools are available for managing invoices?",
            "What are the fees for transactions?",
            "Trigger error test to check validation recovery"
        ]

        for query in queries:
            answer = system.process_query(query)
            print(f"\nFINAL AGENT ANSWER:\n{answer}\n")

