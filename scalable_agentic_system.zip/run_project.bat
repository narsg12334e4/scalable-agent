@echo off
title Scalable Agentic System
:menu
cls
echo ======================================================================
echo             SCALABLE AGENTIC SYSTEM - RUNNER MENU
echo ======================================================================
echo  1. Launch Interactive Website in Browser (Recommended)
echo  2. Start Local Web Server (http://localhost:8000)
echo  3. Run Automated Test Suite in Terminal (All 6 Scenarios)
echo  4. Start Terminal Interactive Chat Mode
echo  5. View Output Log in Notepad
echo  6. Open Project Directory in File Explorer
echo  7. Exit
echo ======================================================================
set /p choice=Select an option [1-7]: 

if "%choice%"=="1" (
    cls
    echo Opening Website in your default browser...
    start "" "%~dp0index.html"
    goto menu
) else if "%choice%"=="2" (
    cls
    echo Starting local web server on http://localhost:8000...
    py "%~dp0server.py"
    pause
    goto menu
) else if "%choice%"=="3" (
    cls
    echo Running Automated Test Suite across 55+ APIs...
    echo.
    py "%~dp0scalable_agent_demo.py"
    echo.
    echo ======================================================================
    pause
    goto menu
) else if "%choice%"=="4" (
    cls
    py "%~dp0scalable_agent_demo.py" --interactive
    pause
    goto menu
) else if "%choice%"=="5" (
    start notepad "%~dp0output.txt"
    goto menu
) else if "%choice%"=="6" (
    start explorer "%~dp0"
    goto menu
) else if "%choice%"=="7" (
    exit
) else (
    echo Invalid choice, please enter 1 to 7.
    pause
    goto menu
)
