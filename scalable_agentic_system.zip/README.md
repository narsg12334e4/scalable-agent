# Scalable Agentic System: Designing for Massive Tool Catalogs

This repository contains the complete architectural proposal, engineering analysis, and functional reference prototype for **"Task: Design a Scalable Agentic System"**.

---

## 📁 Repository Contents

| File | Description |
| :--- | :--- |
| **`scalable_agentic_system_architecture.md`** | **Primary Deliverable**: Comprehensive 360-degree architectural design whitepaper covering problem decomposition, the 3-Tier Hierarchical Dynamic Tooling Architecture (HDTA), PayPal 50-to-500+ scaling, RAG Pipeline Tool, System Search Tool, LangGraph vs LlamaIndex vs CrewAI vs DSPy comparison, state management, and LangSmith observability. |
| **`scalable_agent_demo.py`** | **Runnable Reference Prototype**: Demonstrating 55+ tool catalog indexing, dynamic semantic tool retrieval (Tool-RAG), 2-tier routing, multi-step invoicing, reporting, dispute checks, knowledge search, capability introspection, and self-correcting error handling. |
| **`implementation_plan.md`** | Technical implementation plan, verification matrix, and architectural rationale. |
| **`requirements.txt`** | Dependency definitions for production deployment and local prototype execution. |

---

## 🚀 Quickstart: Running the Reference Prototype

The prototype runs with Python 3.8+ and uses standard library modules for zero-friction evaluation:

```bash
python scalable_agent_demo.py
```

### Verified Test Scenarios Executed:
1. **Multi-Step Invoicing**: `"Send an invoice for $50 to client@example.com"` (plans and executes draft creation followed by invoice send).
2. **Reporting & Analytics**: `"What was my total sales volume last month?"` (derives date boundaries and returns aggregated transaction volume).
3. **Dispute Resolution**: `"Is there a dispute open from user_123?"` (queries dispute claims and returns status & deadline).
4. **System Search Tool**: `"What tools are available for managing invoices?"` (introspects capability manifest).
5. **RAG Pipeline Tool**: `"What are the fees for transactions?"` (queries knowledge base for cross-border and domestic rates).
6. **Error Resilience & Self-Healing**: `"Trigger error test to check validation recovery"` (intercepts missing parameters and executes self-correction loop).

---

## 🏛️ Architecture Overview: Hierarchical Dynamic Tooling Architecture (HDTA)

```
[User Natural Language Input]
             │
             ▼
[Tier 1: Global Intent Router & Orchestrator] (Fast LLM, Domain Classifier)
             │
             ├──► [Dynamic Tool RAG: Hybrid Dense + BM25 Search + Re-ranker]
             │         │
             │         ▼ Prunes 500+ tools down to Top 3-5 schemas
             ▼
[Tier 2: Domain Specialist Execution Node] (Invoicing / Payments / Disputes)
             │
             ├──► [Feature 1: RAG Pipeline Tool] (Policies & Docs)
             ├──► [Feature 2: System Search Tool] (Capabilities & Execution Logs)
             │
             ▼
[Execution & Self-Healing Gateway] (Pydantic Schema Validation + Reflection Loop)
```

---

## 📊 Framework Justification Summary

- **Orchestration**: **LangGraph** is selected for stateful cyclic multi-agent execution, PostgreSQL checkpointers, and human-in-the-loop controls for financial transactions.
- **Tool Discovery & Knowledge**: **LlamaIndex / Qdrant** provides the sub-second hybrid retrieval pipeline to index and fetch tools dynamically.
- **Observability**: **LangSmith & OpenTelemetry** track end-to-end tool retrieval recall, execution latency, and token savings (98%+ reduction).
